
#2024-05-18-1

#pip install azure-cognitiveservices-speech

import os
import azure.cognitiveservices.speech as speechsdk

#voice = 'en-US-AvaMultilingualNeural'
#voice = "bs-BA-VesnaNeural" 
#voice = "bs-BA-GoranNeural"
#voice = "hr-HR-GabrijelaNeural"
#voice = "hr-HR-SreckoNeural"

#voice = "sr-Latn-RS-NicholasNeural"
voice = "sr-Latn-RS-SophieNeural"
#cirilica 
voice = "sr-RS-SophieNeural" 
#voice = 'sr-RS-NicholasNeural'

# This example requires environment variables named "SPEECH_KEY" and "SPEECH_REGION"
speech_config = speechsdk.SpeechConfig(subscription="ENTERYOURKEYHERE", region="ENTERYOURLOCATIONHERE")
audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)

# The neural multilingual voice can speak different languages based on the input text.
speech_config.speech_synthesis_voice_name=voice
#speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3)



# Get text from the console and synthesize to the default speaker.
#print("Enter some text that you want to speak >")
#text = input()

'''
with open('data.txt', 'r') as file:
    data = file.read().replace('\n', '')

Or if the file content is guaranteed to be one line:

with open('data.txt', 'r') as file:
    data = file.read().rstrip()

'''

filename = '1.txt'
with open(filename, 'r', encoding="utf-8") as file:
    text = file.read().replace('\n', '')


#use None for tts2wav, or just comment line below with # for speaker output
audio_config=None

speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
speech_synthesis_result = speech_synthesizer.speak_text_async(text).get()

if audio_config == None:
    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        #print("Speech synthesized to speaker for text [{}]".format(text))
        print('done')
        stream = speechsdk.AudioDataStream(speech_synthesis_result)
        stream.save_to_wav_file(filename+'-'+voice+'.wav')
    
else:
    if speech_synthesis_result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("Speech synthesized for text [{}]".format(text))
    elif speech_synthesis_result.reason == speechsdk.ResultReason.Canceled:
        cancellation_details = speech_synthesis_result.cancellation_details
        print("Speech synthesis canceled: {}".format(cancellation_details.reason))
        if cancellation_details.reason == speechsdk.CancellationReason.Error:
            if cancellation_details.error_details:
                print("Error details: {}".format(cancellation_details.error_details))
                print("Did you set the speech resource key and region values?")
